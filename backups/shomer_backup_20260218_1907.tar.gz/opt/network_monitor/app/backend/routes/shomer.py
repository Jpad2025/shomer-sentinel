"""
API SHOMER: status, metrics, inventory, reboot manual.
Puente entre Monitor, Dashboard y Frontend.
"""
from datetime import datetime
from fastapi import APIRouter, HTTPException
import subprocess
import os
import sys

from db import get_connection

SSHPASS_PATH = "/usr/bin/sshpass"
SSH_PATH = "/usr/bin/ssh"
GATEWAY_IP = "192.168.1.210"
SSH_USER = "root"
SSH_PASSWORD = "Usbing08@2026"
SSH_TIMEOUT = 10

router = APIRouter(prefix="/api", tags=["shomer"])


@router.get("/status")
async def get_status():
    """Contenido actual de system_state."""
    try:
        with get_connection() as conn:
            cur = conn.cursor()
            cur.execute(
                "CREATE TABLE IF NOT EXISTS system_state (key TEXT PRIMARY KEY, value TEXT, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)"
            )
            conn.commit()
            cur.execute("SELECT key, value, updated_at FROM system_state")
            rows = cur.fetchall()
        return {"success": True, "state": {r["key"]: {"value": r["value"], "updated_at": r["updated_at"]} for r in rows}}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/metrics")
async def get_metrics(limit: int = 50):
    """Últimos N registros de server_metrics (default 50)."""
    try:
        with get_connection() as conn:
            cur = conn.cursor()
            cur.execute("""
                CREATE TABLE IF NOT EXISTS server_metrics (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    cpu_usage REAL, ram_usage REAL, temperature REAL,
                    recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            conn.commit()
            cur.execute(
                "SELECT id, cpu_usage, ram_usage, temperature, recorded_at FROM server_metrics ORDER BY recorded_at DESC LIMIT ?",
                (limit,),
            )
            rows = cur.fetchall()
        return {"success": True, "count": len(rows), "metrics": [dict(r) for r in rows]}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/inventory")
async def get_inventory(limit: int = 500):
    """Lista devices_inventory (huéspedes no promovidos)."""
    try:
        with get_connection() as conn:
            cur = conn.cursor()
            cur.execute("""
                CREATE TABLE IF NOT EXISTS devices_inventory (
                    mac_address TEXT PRIMARY KEY, ip_address TEXT, hostname TEXT,
                    last_seen TIMESTAMP, promoted INTEGER DEFAULT 0
                )
            """)
            conn.commit()
            cur.execute(
                "SELECT mac_address, ip_address, hostname, last_seen, promoted FROM devices_inventory WHERE promoted = 0 ORDER BY last_seen DESC LIMIT ?",
                (limit,),
            )
            rows = cur.fetchall()
        return {"success": True, "count": len(rows), "inventory": [dict(r) for r in rows]}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


def _run_reboot_ssh() -> tuple[bool, str]:
    """Ejecuta sshpass + ssh reboot al Gateway .210."""
    cmd = [
        SSHPASS_PATH, "-p", SSH_PASSWORD, SSH_PATH,
        "-o", "StrictHostKeyChecking=no", "-o", "UserKnownHostsFile=/dev/null",
        "-o", "ConnectTimeout=5",
        "-p", "22", f"{SSH_USER}@{GATEWAY_IP}", "/sbin/reboot",
    ]
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=SSH_TIMEOUT)
        if proc.returncode == 0:
            return True, "Reboot enviado al Gateway .210"
        return False, f"SSH falló: {proc.stderr or proc.stdout or 'código ' + str(proc.returncode)}"
    except subprocess.TimeoutExpired:
        return True, "Reboot enviado (timeout esperado durante reinicio)"
    except FileNotFoundError:
        return False, "sshpass o ssh no encontrado"
    except Exception as e:
        return False, str(e)


@router.post("/reboot")
async def manual_reboot():
    """Ejecuta reinicio SSH al Gateway .210 de forma manual."""
    ok, msg = _run_reboot_ssh()
    if not ok and "timeout" not in msg.lower():
        raise HTTPException(status_code=500, detail=msg)
    return {"success": ok, "message": msg}
