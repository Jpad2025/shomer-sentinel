#!/bin/bash
# Script para reiniciar TP-Link Archer C54 usando puerto 80
# Desarrollado por USB Ingeniería SAS

ROUTER_IP="192.168.1.200"
ROUTER_PORT="80"
ROUTER_PASSWORD="Usbing08*"

echo "=== REINICIO DE ROUTER TP-LINK ARCHER C54 ==="
echo "Router: $ROUTER_IP:$ROUTER_PORT"

# Paso 1: Intentar login para obtener token
echo "Paso 1: Iniciando sesión..."
RESPONSE=$(curl -s -X POST "http://$ROUTER_IP:$ROUTER_PORT/cgi-bin/luci/;stok=/login?form=login" \
  -H "Content-Type: application/json" \
  -d "{\"operation\":\"login\",\"password\":\"$ROUTER_PASSWORD\"}")

# Extraer token de la respuesta
TOKEN=$(echo "$RESPONSE" | grep -o '"stok":"[^"]*"' | cut -d'"' -f4)

if [ -z "$TOKEN" ]; then
  echo "❌ Error: No se pudo obtener token de autenticación"
  echo "Respuesta del router: $RESPONSE"
  exit 1
fi

echo "✅ Login exitoso, token obtenido: $TOKEN"

# Paso 2: Enviar comando de reinicio
echo "Paso 2: Enviando comando de reinicio..."
REBOOT_RESPONSE=$(curl -s -X POST "http://$ROUTER_IP:$ROUTER_PORT/cgi-bin/luci/;stok=$TOKEN/admin/system?form=reboot" \
  -H "Content-Type: application/json" \
  -d "{\"operation\":\"reboot\"}")

echo "Respuesta de reinicio: $REBOOT_RESPONSE"

# Verificar si el reinicio fue exitoso
if echo "$REBOOT_RESPONSE" | grep -q '"success":true'; then
  echo "✅ Comando de reinicio enviado exitosamente"
  echo "El router se reiniciará en breve"
  exit 0
else
  echo "❌ Error al enviar comando de reinicio"
  echo "Respuesta del router: $REBOOT_RESPONSE"
  exit 1
fi
