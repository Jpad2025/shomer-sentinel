#!/usr/bin/env python3
"""
Script para reiniciar routers mediante HTTP
Desarrollado por USB Ingeniería SAS
"""
import requests
import sys
import time
import logging
import json
import argparse

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def reboot_via_http(ip, username, password, port=2222):
    """Reinicia un router mediante su interfaz HTTP"""
    session = requests.Session()
    session.verify = False
    
    try:
        # 1. Intentar login
        login_url = f"http://{ip}:{port}/cgi-bin/luci/;stok=/login?form=login"
        login_data = {"operation": "login", "password": password}
        
        logger.info(f"Intentando login en {login_url}")
        response = session.post(login_url, json=login_data, timeout=10)
        
        if response.status_code != 200:
            logger.error(f"Error de autenticación: {response.status_code}")
            return False, f"Error de autenticación: {response.status_code}"
        
        # 2. Extraer token de la respuesta
        try:
            data = response.json()
            if not data.get("success"):
                logger.error(f"Login fallido: {data.get('msg', 'credenciales incorrectas')}")
                return False, f"Login fallido: {data.get('msg', 'credenciales incorrectas')}"
            
            stok = data.get("data", {}).get("stok")
            if not stok:
                logger.error("No se pudo obtener token de autenticación")
                return False, "No se pudo obtener token de autenticación"
            
            logger.info(f"Login exitoso, token obtenido: {stok}")
            
            # 3. Enviar comando de reinicio
            reboot_url = f"http://{ip}:{port}/cgi-bin/luci/;stok={stok}/admin/system?form=reboot"
            reboot_data = {"operation": "reboot"}
            
            logger.info(f"Enviando comando de reinicio a {reboot_url}")
            response = session.post(reboot_url, json=reboot_data, timeout=10)
            
            if response.status_code == 200:
                try:
                    data = response.json()
                    if data.get("success"):
                        logger.info(f"Reinicio exitoso para {ip}")
                        return True, "Reinicio exitoso"
                    else:
                        logger.error(f"Error en respuesta de reinicio: {data}")
                        return False, f"Error en respuesta de reinicio: {data}"
                except:
                    # Si no podemos procesar la respuesta pero el código es 200, asumimos éxito
                    logger.info(f"Reinicio posiblemente exitoso para {ip}")
                    return True, "Reinicio posiblemente exitoso"
            else:
                logger.error(f"Error al reiniciar: {response.status_code}")
                return False, f"Error al reiniciar: {response.status_code}"
        except Exception as e:
            logger.error(f"Error procesando respuesta: {str(e)}")
            return False, f"Error procesando respuesta: {str(e)}"
    except requests.exceptions.Timeout:
        # El timeout puede indicar que el reinicio fue exitoso
        logger.info(f"Timeout en {ip} - posiblemente reiniciando")
        return True, "Reinicio iniciado (timeout esperado)"
    except Exception as e:
        logger.error(f"Error general: {str(e)}")
        return False, str(e)

def main():
    parser = argparse.ArgumentParser(description="Reiniciar router mediante HTTP")
    parser.add_argument("ip", help="Dirección IP del router")
    parser.add_argument("--username", default="admin", help="Nombre de usuario")
    parser.add_argument("--password", default="Usbing08*", help="Contraseña")
    parser.add_argument("--port", type=int, default=2222, help="Puerto HTTP")
    
    args = parser.parse_args()
    
    success, message = reboot_via_http(args.ip, args.username, args.password, args.port)
    
    if success:
        print(f"✅ Reinicio exitoso: {message}")
        sys.exit(0)
    else:
        print(f"❌ Reinicio fallido: {message}")
        sys.exit(1)

if __name__ == "__main__":
    main()
