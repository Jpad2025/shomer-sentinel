"""
Módulo de alertas por Telegram - Producción
Desarrollado por USB Ingeniería SAS y USB Engineers LLC
Filtro de hierro: regex .21, whitelist SHOMER/Gateway/.210, etiquetas obligatorias.
"""
import re
import logging
import requests

TELEGRAM_BOT_TOKEN = "8581376385:AAF6YYJ0fteTekQIiedNXn-NDb2AgI8-05Y"
TELEGRAM_CHAT_ID = "6513540405"
RED_MONITOREDA = "Hotel El Buen Descanso"

MSG_INICIO = "🛡️ SALUD DE NODOS | SHOMER v1.0 Activo | Servidor .205 OK | Gateway .210 OK."

ALLOWED_TAGS = ("PÉRDIDA DE SERVICIO", "REINICIO EN PROGRESO", "SALUD DE NODOS")
BLOCK_IP_REGEX = re.compile(r"192\.168\.1\.21(?!0)")

logger = logging.getLogger("alerts")


def send_telegram_alert(message: str) -> bool:
    """
    Envía mensaje por Telegram. Filtro de hierro:
    - Bloquea r"192\.168\.1\.21(?!0)" (spam IP .21)
    - Whitelist: SHOMER, Gateway o 192.168.1.210
    - Etiquetas: solo PÉRDIDA DE SERVICIO, REINICIO EN PROGRESO, SALUD DE NODOS
    """
    if not TELEGRAM_BOT_TOKEN or TELEGRAM_BOT_TOKEN == "YOUR_BOT_TOKEN":
        logger.debug("Telegram: TOKEN no configurado, alerta omitida")
        return False
    if not TELEGRAM_CHAT_ID or TELEGRAM_CHAT_ID == "YOUR_CHAT_ID":
        logger.debug("Telegram: CHAT_ID no configurado, alerta omitida")
        return False
    msg = message or ""
    if BLOCK_IP_REGEX.search(msg):
        logger.debug("Telegram: bloqueado (IP .21)")
        return False
    if "SHOMER" not in msg and "Gateway" not in msg and "192.168.1.210" not in msg:
        logger.debug("Telegram: bloqueado (no whitelist)")
        return False
    if not any(tag in msg for tag in ALLOWED_TAGS):
        logger.debug("Telegram: bloqueado (falta etiqueta permitida)")
        return False

    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
    payload = {"chat_id": TELEGRAM_CHAT_ID, "text": msg, "parse_mode": "HTML"}
    try:
        r = requests.post(url, json=payload, timeout=10)
        if r.status_code == 200:
            logger.info("Telegram: alerta enviada")
            return True
        logger.warning("Telegram: fallo HTTP %d - %s", r.status_code, (r.text or "")[:200])
        return False
    except Exception as e:
        logger.warning("Telegram: error enviando alerta: %s", e)
        return False
