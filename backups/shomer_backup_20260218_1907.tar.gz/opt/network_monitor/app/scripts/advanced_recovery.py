"""
Módulo de recuperación avanzada para routers
Desarrollado por USB Ingeniería SAS y USB Engineers LLC
"""
import sys
import os
import time
import logging
import subprocess
import socket
import requests
from typing import Tuple, Dict, List, Any, Optional

# Configurar logging
logger = logging.getLogger(__name__)

# Importar gestor HTTP si está disponible
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
try:
    from backend.router_http_manager import RouterHTTPManager
    HTTP_MANAGER_AVAILABLE = True
except ImportError:
    HTTP_MANAGER_AVAILABLE = False
    logger.warning("RouterHTTPManager no disponible")

class AdvancedRecoveryManager:
    """Gestor avanzado de recuperación de dispositivos de red"""

    def __init__(self, authorization_level=2, timeout=10):
        """
        Inicializar gestor con nivel de autorización:
        1 = Solo métodos estándar
        2 = Incluye métodos avanzados (requiere autorización explícita)
        """
        self.authorization_level = authorization_level
        self.timeout = timeout

        # Inicializar gestor HTTP si está disponible
        self.http_manager = None
        if HTTP_MANAGER_AVAILABLE:
            try:
                self.http_manager = RouterHTTPManager(timeout=timeout, authorization_level=authorization_level)
                logger.info(f"RouterHTTPManager inicializado (auth_level: {authorization_level})")
            except Exception as e:
                logger.error(f"Error inicializando RouterHTTPManager: {str(e)}")
    
    def recover_device(self, device: Dict[str, Any]) -> Tuple[bool, str]:
        """
        Intenta recuperar un dispositivo usando métodos progresivamente más avanzados
        """
        device_id = device.get('id')
        ip = device.get('ip_address')
        name = device.get('name')
        mac = device.get('mac_address')
        brand = device.get('brand', 'auto')
        
        logger.info(f"Iniciando recuperación avanzada de {name} ({ip})")
        
        # Verificar si el dispositivo ya está online
        if self._ping_device(ip):
            logger.info(f"El dispositivo {name} ya está online")
            return True, "El dispositivo ya está online"
        
        # Método 1: Reinicio HTTP en puerto 80 (nuevo método prioritario)
        success, message = self._try_port80_reboot(device)
        if success:
            logger.info(f"Recuperación HTTP puerto 80 exitosa para {name}: {message}")
            return True, f"Recuperado con HTTP puerto 80: {message}"
        else:
            logger.warning(f"Recuperación HTTP puerto 80 fallida para {name}: {message}")
        
        # Método 2: Recuperación HTTP (original)
        if self.http_manager:
            logger.info(f"Intentando recuperación HTTP para {name}")
            username = device.get('ssh_user', 'admin')
            password = device.get('ssh_password', 'admin')
            
            success, message = self.http_manager.reboot_device(ip, username, password, brand)
            if success:
                logger.info(f"Recuperación HTTP exitosa para {name}: {message}")
                return True, f"Recuperado con HTTP: {message}"
            else:
                logger.warning(f"Recuperación HTTP fallida para {name}: {message}")
        else:
            logger.warning(f"Gestor HTTP no disponible para {name}")
        
        # Si el método HTTP falló y tenemos autorización, intentar métodos adicionales
        if self.authorization_level >= 2:
            logger.info(f"Intentando métodos adicionales para {name}")
            
            # Método 3: SSH
            success, message = self._try_ssh_recovery(device)
            if success:
                logger.info(f"Recuperación SSH exitosa para {name}: {message}")
                return True, f"Recuperado con SSH: {message}"
            
            # Método 4: Técnicas avanzadas
            success, message = self._try_advanced_techniques(device)
            if success:
                logger.info(f"Recuperación avanzada exitosa para {name}: {message}")
                return True, f"Recuperado con técnicas avanzadas: {message}"
        
        logger.warning(f"Todos los métodos de recuperación fallaron para {name} ({ip})")
        return False, "Todos los métodos de recuperación fallaron"
    
    def _ping_device(self, ip: str, count: int = 1) -> bool:
        """Verifica si un dispositivo responde a ping"""
        try:
            result = subprocess.run(
                f"ping -c {count} -W 2 {ip}",
                shell=True,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL
            )
            return result.returncode == 0
        except Exception as e:
            logger.error(f"Error en ping a {ip}: {str(e)}")
            return False
    
    def _try_port80_reboot(self, device: Dict[str, Any]) -> Tuple[bool, str]:
        """Intenta reiniciar el dispositivo usando HTTP en puerto 80"""
        ip = device.get('ip_address')
        password = device.get('ssh_password', 'Usbing08*')
        
        logger.info(f"Intentando reinicio HTTP en puerto 80 para {ip}")
        
        try:
            # Crear sesión HTTP
            session = requests.Session()
            
            # Paso 1: Intentar login para obtener token
            login_url = f"http://{ip}:80/cgi-bin/luci/;stok=/login?form=login"
            login_data = {"operation": "login", "password": password}
            
            logger.info(f"Enviando solicitud de login a {login_url}")
            response = session.post(login_url, json=login_data, timeout=10)
            
            if response.status_code != 200:
                return False, f"Error de autenticación: {response.status_code}"
            
            # Intentar extraer token de la respuesta
            try:
                data = response.json()
                if not data.get("success"):
                    return False, f"Login fallido: {data.get('msg', 'credenciales incorrectas')}"
                
                stok = data.get("data", {}).get("stok")
                if not stok:
                    return False, "No se pudo obtener token de autenticación"
                
                logger.info(f"Login exitoso, token obtenido: {stok}")
                
                # Paso 2: Enviar comando de reinicio
                reboot_url = f"http://{ip}:80/cgi-bin/luci/;stok={stok}/admin/system?form=reboot"
                reboot_data = {"operation": "reboot"}
                
                logger.info(f"Enviando comando de reinicio a {reboot_url}")
                response = session.post(reboot_url, json=reboot_data, timeout=10)
                
                if response.status_code == 200:
                    try:
                        data = response.json()
                        if data.get("success"):
                            logger.info(f"Reinicio exitoso para {ip}")
                            return True, "Reinicio exitoso"
                        else:
                            return False, f"Error en respuesta de reinicio: {data}"
                    except:
                        # Si no podemos procesar la respuesta pero el código es 200, asumimos éxito
                        return True, "Reinicio posiblemente exitoso"
                else:
                    return False, f"Error al reiniciar: {response.status_code}"
            except Exception as e:
                # Si falla el procesamiento JSON, intentar método alternativo
                logger.warning(f"Error procesando respuesta JSON: {str(e)}")
                
                # Método alternativo: usar curl directamente
                try:
                    # Crear script temporal
                    script_path = "/tmp/reboot_router.sh"
                    with open(script_path, 'w') as f:
                        f.write(f'''#!/bin/bash
ROUTER_IP="{ip}"
ROUTER_PORT="80"
ROUTER_PASSWORD="{password}"

# Paso 1: Intentar login para obtener token
RESPONSE=$(curl -s -X POST "http://$ROUTER_IP:$ROUTER_PORT/cgi-bin/luci/;stok=/login?form=login" \\
  -H "Content-Type: application/json" \\
  -d "{{\\"operation\\":\\"login\\",\\"password\\":\\"$ROUTER_PASSWORD\\"}}")

# Extraer token de la respuesta
TOKEN=$(echo "$RESPONSE" | grep -o '"stok":"[^"]*"' | cut -d'"' -f4)

if [ -z "$TOKEN" ]; then
  echo "Error: No se pudo obtener token de autenticación"
  exit 1
fi

# Paso 2: Enviar comando de reinicio
REBOOT_RESPONSE=$(curl -s -X POST "http://$ROUTER_IP:$ROUTER_PORT/cgi-bin/luci/;stok=$TOKEN/admin/system?form=reboot" \\
  -H "Content-Type: application/json" \\
  -d "{{\\"operation\\":\\"reboot\\"}}")

# Verificar si el reinicio fue exitoso
if echo "$REBOOT_RESPONSE" | grep -q '"success":true'; then
  echo "Comando de reinicio enviado exitosamente"
  exit 0
else
  echo "Error al enviar comando de reinicio"
  exit 1
fi
''')
                    
                    # Dar permisos de ejecución
                    os.chmod(script_path, 0o755)
                    
                    # Ejecutar script
                    result = subprocess.run(script_path, shell=True, capture_output=True, text=True)
                    
                    if result.returncode == 0:
                        logger.info(f"Reinicio exitoso para {ip} usando script curl")
                        return True, "Reinicio exitoso usando script curl"
                    else:
                        logger.error(f"Error en script curl: {result.stderr}")
                        return False, f"Error en script curl: {result.stderr}"
                except Exception as e:
                    logger.error(f"Error ejecutando script curl: {str(e)}")
                    return False, f"Error ejecutando script curl: {str(e)}"
        except requests.exceptions.Timeout:
            # El timeout puede indicar que el reinicio fue exitoso
            logger.info(f"Timeout en {ip} - posiblemente reiniciando")
            return True, "Reinicio iniciado (timeout esperado)"
        except Exception as e:
            logger.error(f"Error general en reinicio HTTP puerto 80: {str(e)}")
            return False, str(e)
    
    def _try_ssh_recovery(self, device: Dict[str, Any]) -> Tuple[bool, str]:
        """Intenta recuperar el dispositivo usando SSH"""
        ip = device.get('ip_address')
        username = device.get('ssh_user', 'admin')
        password = device.get('ssh_password', 'admin')
        
        logger.info(f"Intentando recuperación SSH para {ip}")
        
        try:
            # Verificar si el puerto SSH está abierto
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(2)
            result = sock.connect_ex((ip, 22))
            sock.close()
            
            if result != 0:
                return False, "Puerto SSH cerrado"
            
            # Intentar reinicio por SSH
            cmd = f"sshpass -p '{password}' ssh -o StrictHostKeyChecking=no -o ConnectTimeout=5 {username}@{ip} 'reboot'"
            result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
            
            if result.returncode == 0:
                logger.info(f"Comando SSH ejecutado exitosamente para {ip}")
                return True, "Reinicio SSH exitoso"
            else:
                logger.warning(f"Error en comando SSH para {ip}: {result.stderr}")
                return False, f"Error SSH: {result.stderr}"
        except Exception as e:
            logger.error(f"Error en recuperación SSH para {ip}: {str(e)}")
            return False, f"Error SSH: {str(e)}"
    
    def _try_advanced_techniques(self, device: Dict[str, Any]) -> Tuple[bool, str]:
        """Intenta técnicas avanzadas de recuperación"""
        ip = device.get('ip_address')
        
        logger.info(f"Intentando técnicas avanzadas para {ip}")
        
        # Método 1: TCP Connection Flood
        success, message = self._try_tcp_connection_flood(ip)
        if success:
            return True, f"Recuperado con TCP Connection Flood: {message}"
        
        # Método 2: HTTP Flood
        success, message = self._try_http_flood(ip)
        if success:
            return True, f"Recuperado con HTTP Flood: {message}"
        
        return False, "Todas las técnicas avanzadas fallaron"
    
    def _try_tcp_connection_flood(self, ip: str) -> Tuple[bool, str]:
        """Intenta reiniciar el dispositivo mediante sobrecarga de conexiones TCP"""
        logger.info(f"Intentando TCP Connection Flood para {ip}")
        
        try:
            # Crear múltiples conexiones TCP en puertos comunes
            ports = [80, 443, 8080, 8443, 22, 23]
            max_connections = 100
            connection_time = 30  # segundos
            
            start_time = time.time()
            connections = []
            
            while time.time() - start_time < connection_time:
                for port in ports:
                    try:
                        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                        sock.settimeout(1)
                        sock.connect_ex((ip, port))
                        connections.append(sock)
                        
                        if len(connections) >= max_connections:
                            # Cerrar algunas conexiones para evitar agotamiento de recursos
                            for i in range(max_connections // 2):
                                try:
                                    connections[i].close()
                                except:
                                    pass
                            connections = connections[max_connections // 2:]
                    except:
                        pass
                
                # Verificar si el dispositivo ya no responde (posible reinicio)
                if not self._ping_device(ip):
                    logger.info(f"Dispositivo {ip} no responde - posible reinicio")
                    
                    # Cerrar todas las conexiones
                    for sock in connections:
                        try:
                            sock.close()
                        except:
                            pass
                    
                    return True, "Dispositivo reiniciado por sobrecarga TCP"
                
                time.sleep(1)
            
            # Cerrar todas las conexiones
            for sock in connections:
                try:
                    sock.close()
                except:
                    pass
            
            return False, "TCP Connection Flood no provocó reinicio"
        except Exception as e:
            logger.error(f"Error en TCP Connection Flood para {ip}: {str(e)}")
            return False, f"Error en TCP Connection Flood: {str(e)}"
    
    def _try_http_flood(self, ip: str) -> Tuple[bool, str]:
        """Intenta reiniciar el dispositivo mediante sobrecarga de peticiones HTTP"""
        logger.info(f"Intentando HTTP Flood para {ip}")
        
        try:
            # Crear múltiples peticiones HTTP
            urls = [
                f"http://{ip}/",
                f"http://{ip}/index.html",
                f"http://{ip}/status.html"
            ]
            max_requests = 500
            request_time = 100  # segundos
            
            start_time = time.time()
            count = 0
            
            session = requests.Session()
            
            while time.time() - start_time < request_time and count < max_requests:
                for url in urls:
                    try:
                        response = session.get(url, timeout=1)
                        count += 1
                    except:
                        pass
                
                # Verificar si el dispositivo ya no responde (posible reinicio)
                if not self._ping_device(ip):
                    logger.info(f"Dispositivo {ip} no responde - posible reinicio")
                    return True, "Dispositivo reiniciado por HTTP Flood"
            
            return False, "HTTP flood no provocó reinicio"
        except Exception as e:
            logger.error(f"Error en HTTP Flood para {ip}: {str(e)}")
            return False, f"Error en HTTP Flood: {str(e)}"

# Instancia global para uso directo
advanced_recovery = AdvancedRecoveryManager(authorization_level=2)

def recover_device(device: Dict[str, Any]) -> Tuple[bool, str]:
    """Función de conveniencia para recuperar un dispositivo"""
    return advanced_recovery.recover_device(device)
