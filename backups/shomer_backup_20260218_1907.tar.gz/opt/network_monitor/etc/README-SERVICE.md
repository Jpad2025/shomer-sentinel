# Servicio systemd SHOMER Monitor

Para que el monitor se ejecute como servicio y no se detenga al cerrar la terminal:

```bash
# Copiar unidad
sudo cp /opt/network_monitor/etc/shomer-monitor.service /etc/systemd/system/

# Recargar systemd
sudo systemctl daemon-reload

# Habilitar al arranque
sudo systemctl enable shomer-monitor

# Iniciar ahora
sudo systemctl start shomer-monitor

# Estado y logs
sudo systemctl status shomer-monitor
journalctl -u shomer-monitor -f
```

Requisitos: Redis en 127.0.0.1:6379 y llave SSH `~/.ssh/id_rsa_shomer`.
