# SCRIPT DE DISCOVERY AUTOMATIZADO DE RED
# Inventario pasivo: lee la tabla ARP del router vía SSH (sin pings masivos).
# Ubicación: /opt/network_monitor/app/backend/scripts/discovery.py

import subprocess
import json
import sqlite3
import re
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager
from datetime import datetime, timedelta
from typing import List, Dict, Tuple, Optional
import logging

# Configuración
DB_PATH = "/opt/network_monitor/database/network_monitor.db"
CONNECT_TIMEOUT = 30  # SQLite: espera hasta 30 s si la BD está bloqueada

# Router desde el que leer ARP vía SSH (mismo que reboot: GL-MT6000 id=5)
ARP_ROUTER_DEVICE_ID = 5
SSHPASS_PATH = "/usr/bin/sshpass"
SSH_PATH = "/usr/bin/ssh"
SSH_TIMEOUT_SEC = 15
# Broadcast para refrescar ARP antes de leer la tabla (despertar vecinos, p. ej. 192.168.1.20)
ARP_REFRESH_BROADCAST = "192.168.1.255"
# Barrido de pings desde el Mini PC (192.168.1.1-254) para poblar ARP del Mini PC y del router
PING_SWEEP_NETWORK = "192.168.1"
PING_SWEEP_FIRST = 1
PING_SWEEP_LAST = 254
PING_SWEEP_TIMEOUT = 1
PING_SWEEP_WORKERS = 64

# Configuración de logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('/opt/network_monitor/logs/discovery.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)


@contextmanager
def get_conn():
    """Conexión SQLite con timeout y WAL. Usar con 'with'."""
    conn = sqlite3.connect(DB_PATH, timeout=CONNECT_TIMEOUT)
    conn.execute("PRAGMA journal_mode=WAL;")
    conn.row_factory = sqlite3.Row
    try:
        yield conn
    finally:
        conn.close()


def get_credentials_from_db(device_id: int) -> Optional[Tuple[str, str, str]]:
    """Obtiene (ip_address, ssh_user, ssh_password) del router para ARP vía SSH."""
    try:
        with get_conn() as conn:
            cur = conn.cursor()
            cur.execute(
                "SELECT ip_address, ssh_user, ssh_password FROM devices WHERE id = ? AND is_active = 1",
                (device_id,),
            )
            row = cur.fetchone()
            if not row or not row["ip_address"] or not row["ssh_user"] or not row["ssh_password"]:
                return None
            return (row["ip_address"], row["ssh_user"], row["ssh_password"])
    except Exception as e:
        logger.error("Error leyendo credenciales del router: %s", e)
        return None


def run_ssh_command(host: str, user: str, password: str, command: str, timeout: int = SSH_TIMEOUT_SEC) -> bool:
    """Ejecuta un comando en el router vía SSH. Devuelve True si salida 0."""
    cmd = [
        SSHPASS_PATH, "-p", password, SSH_PATH,
        "-o", "StrictHostKeyChecking=no",
        "-o", "UserKnownHostsFile=/dev/null",
        "-o", "PreferredAuthentications=password",
        f"{user}@{host}",
        command,
    ]
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return proc.returncode == 0
    except Exception as e:
        logger.debug("SSH command failed: %s", e)
        return False


def run_local_ping_sweep() -> None:
    """
    Barrido rápido de pings desde el Mini PC al rango 192.168.1.1-254.
    Pobla la tabla ARP del Mini PC y del router (tráfico pasa por el gateway).
    Usa fping si está disponible, si no un loop de pings en paralelo.
    """
    try:
        proc = subprocess.run(
            ["which", "fping"], capture_output=True, text=True, timeout=2
        )
        if proc.returncode == 0 and proc.stdout.strip():
            cmd = ["fping", "-r", "1", "-t", str(PING_SWEEP_TIMEOUT * 1000), "-g", f"{PING_SWEEP_NETWORK}.0/24"]
            subprocess.run(cmd, capture_output=True, timeout=15)
            logger.info("Barrido ARP: fping 192.168.1.0/24 ejecutado")
            return
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass
    # Fallback: pings en paralelo
    def ping_one(ip: str) -> bool:
        try:
            r = subprocess.run(
                ["ping", "-c", "1", "-W", str(PING_SWEEP_TIMEOUT), ip],
                capture_output=True, text=True, timeout=PING_SWEEP_TIMEOUT + 1,
            )
            return r.returncode == 0
        except Exception:
            return False

    ips = [f"{PING_SWEEP_NETWORK}.{i}" for i in range(PING_SWEEP_FIRST, PING_SWEEP_LAST + 1)]
    with ThreadPoolExecutor(max_workers=PING_SWEEP_WORKERS) as ex:
        list(ex.map(ping_one, ips))
    logger.info("Barrido ARP: %d pings ejecutados (192.168.1.%d-%d)", len(ips), PING_SWEEP_FIRST, PING_SWEEP_LAST)


def refresh_arp_via_ssh(host: str, user: str, password: str) -> None:
    """Antes de leer ARP: ping broadcast en el router para despertar vecinos y refrescar la tabla."""
    # ping -c 1 192.168.1.255 (broadcast) para que el router actualice su caché ARP
    cmd = f"ping -c 1 -W 2 {ARP_REFRESH_BROADCAST}"
    if run_ssh_command(host, user, password, cmd, timeout=10):
        logger.info("Refresco ARP: broadcast %s ejecutado en el router", ARP_REFRESH_BROADCAST)
    else:
        logger.warning("Refresco ARP: ping broadcast falló (seguimos con la tabla actual)")


def get_arp_via_ssh(host: str, user: str, password: str) -> List[Dict[str, str]]:
    """
    Lee la tabla ARP del router vía SSH (sin pings). Compatible con OpenWrt/GL-iNet.
    Antes ejecuta ping broadcast para refrescar ARP. Luego: cat /proc/net/arp.
    Returns: lista de {"ip": "x.x.x.x", "mac": "XX:XX:XX:XX:XX:XX"}
    """
    entries = []
    # /proc/net/arp: IP at column 0, HW address at column 3; skip header and 0.0.0.0
    cmd = [
        SSHPASS_PATH, "-p", password, SSH_PATH,
        "-o", "StrictHostKeyChecking=no",
        "-o", "UserKnownHostsFile=/dev/null",
        "-o", "PreferredAuthentications=password",
        f"{user}@{host}",
        "cat /proc/net/arp",
    ]
    try:
        proc = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=SSH_TIMEOUT_SEC,
        )
        if proc.returncode != 0:
            logger.warning("ARP vía SSH falló (code %s): %s", proc.returncode, (proc.stderr or "").strip())
            return entries
        for line in proc.stdout.strip().splitlines():
            parts = line.split()
            if len(parts) < 4:
                continue
            ip_addr = parts[0]
            if ip_addr == "IP" or ip_addr == "0.0.0.0":
                continue
            hw = parts[3]
            if hw == "00:00:00:00:00:00" or "*" in hw:
                continue
            mac = hw.upper().replace("-", ":")
            if re.match(r"^([0-9A-F]{2}:){5}[0-9A-F]{2}$", mac):
                entries.append({"ip": ip_addr, "mac": mac})
    except subprocess.TimeoutExpired:
        logger.error("Timeout leyendo ARP vía SSH")
    except FileNotFoundError:
        logger.error("sshpass/ssh no encontrado (ruta: %s)", SSHPASS_PATH)
    except Exception as e:
        logger.exception("Error leyendo ARP vía SSH: %s", e)
    return entries


def _ensure_mac_unique_index(conn):
    """Índice UNIQUE en mac_address para ON CONFLICT(mac_address)."""
    try:
        conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_discovered_devices_mac ON discovered_devices(mac_address)")
        conn.commit()
    except Exception as e:
        logger.warning("Índice mac_address (puede haber MACs duplicadas): %s", e)


def save_discovered_device(device_info: Dict) -> bool:
    """
    Guardar dispositivo descubierto. Validación: ip_address y mac_address no vacíos.
    hostname/vendor: '' o 'Unknown' si vienen vacíos. Upsert por mac_address.
    """
    ip_addr = (device_info.get("ip_address") or "").strip()
    mac = (device_info.get("mac_address") or "").strip()
    if not ip_addr or not mac:
        logger.debug("Registro descartado: ip_address o mac_address vacíos (ip=%r, mac=%r)", ip_addr or None, mac or None)
        return False

    hostname = (device_info.get("hostname") or "").strip() or "Unknown"
    vendor = (device_info.get("vendor") or "").strip() or "Unknown"
    last_seen = (device_info.get("last_seen") or "").strip() or datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S.%f")
    status = (device_info.get("status") or "").strip() or "online"

    try:
        with get_conn() as conn:
            _ensure_mac_unique_index(conn)
            cur = conn.cursor()
            try:
                cur.execute("""
                    INSERT INTO discovered_devices (ip_address, mac_address, hostname, vendor, last_seen, status, first_seen, source, open_ports, inferred_type)
                    VALUES (?, ?, ?, ?, ?, ?, ?, 'arp_ssh', '[]', 'unknown')
                    ON CONFLICT(mac_address) DO UPDATE SET
                        ip_address = excluded.ip_address,
                        last_seen = excluded.last_seen,
                        status = excluded.status
                """, (ip_addr, mac, hostname, vendor, last_seen, status, last_seen))
            except (sqlite3.IntegrityError, sqlite3.OperationalError):
                cur.execute("SELECT id FROM discovered_devices WHERE mac_address = ?", (mac,))
                row = cur.fetchone()
                if row:
                    cur.execute(
                        "UPDATE discovered_devices SET ip_address = ?, last_seen = ?, status = ? WHERE mac_address = ?",
                        (ip_addr, last_seen, status, mac),
                    )
                else:
                    cur.execute("""
                        INSERT INTO discovered_devices (ip_address, mac_address, hostname, vendor, last_seen, status, first_seen, source, open_ports, inferred_type)
                        VALUES (?, ?, ?, ?, ?, ?, ?, 'arp_ssh', '[]', 'unknown')
                    """, (ip_addr, mac, hostname, vendor, last_seen, status, last_seen))
            conn.commit()
        logger.info("Dispositivo descubierto: %s / %s", ip_addr, mac)
        return True
    except Exception as e:
        logger.error("Error en BD: %s", e)
        return False


def cleanup_old_discoveries():
    """Marcar dispositivos offline que no se han visto en X tiempo"""
    try:
        with get_conn() as conn:
            cur = conn.cursor()
            cutoff = (datetime.utcnow() - timedelta(minutes=30)).strftime("%Y-%m-%d %H:%M:%S.%f")
            cur.execute(
                "UPDATE discovered_devices SET status = 'offline' WHERE last_seen < ? AND status = 'online'",
                (cutoff,)
            )
            if cur.rowcount > 0:
                logger.info(f"Marcados {cur.rowcount} dispositivos como offline")
            conn.commit()
    except Exception as e:
        logger.error(f"Error limpiando discoveries viejos: {str(e)}")


def ensure_assets_table(conn):
    """Crear tabla assets si no existe (inventario permanente)."""
    conn.execute("""
        CREATE TABLE IF NOT EXISTS assets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            mac_address TEXT NOT NULL UNIQUE,
            ip_address TEXT,
            hostname TEXT,
            vendor TEXT,
            first_seen TEXT,
            last_seen TEXT,
            source TEXT
        )
    """)
    try:
        conn.execute("CREATE INDEX IF NOT EXISTS idx_assets_last_seen ON assets(last_seen)")
    except Exception:
        pass
    conn.commit()


def sync_arp_to_assets(arp_entries: List[Dict[str, str]], now: str) -> None:
    """Tras el discovery pasivo: guardar en assets para inventario permanente (huéspedes)."""
    valid = [e for e in (arp_entries or []) if (e.get("ip") or "").strip() and (e.get("mac") or "").strip()]
    if not valid:
        return
    try:
        with get_conn() as conn:
            ensure_assets_table(conn)
            cur = conn.cursor()
            for e in valid:
                mac, ip_addr = (e["mac"] or "").strip(), (e["ip"] or "").strip()
                if not mac or not ip_addr:
                    continue
                cur.execute("SELECT id FROM assets WHERE mac_address = ?", (mac,))
                if cur.fetchone():
                    cur.execute(
                        "UPDATE assets SET ip_address = ?, last_seen = ? WHERE mac_address = ?",
                        (ip_addr, now, mac),
                    )
                else:
                    cur.execute(
                        "INSERT INTO assets (mac_address, ip_address, hostname, vendor, first_seen, last_seen, source) VALUES (?, ?, NULL, NULL, ?, ?, 'arp_ssh')",
                        (mac, ip_addr, now, now),
                    )
            conn.commit()
        logger.info("Sincronizados %d activos a tabla assets", len(valid))
    except Exception as e:
        logger.warning("Error sincronizando a assets: %s", e)


def run_discovery():
    """
    Inventario pasivo: lee la tabla ARP del router vía SSH.
    No hace pings masivos ni escaneo de puertos; no estresa la interfaz de red.
    """
    logger.info("=" * 60)
    logger.info("Iniciando inventario pasivo (ARP vía SSH)")
    logger.info("=" * 60)

    creds = get_credentials_from_db(ARP_ROUTER_DEVICE_ID)
    if not creds:
        logger.error("No se encontraron credenciales SSH del router (device_id=%s). Revisa la tabla devices.", ARP_ROUTER_DEVICE_ID)
        return 0

    host, user, password = creds
    run_local_ping_sweep()
    refresh_arp_via_ssh(host, user, password)
    arp_entries = get_arp_via_ssh(host, user, password)
    logger.info("Entradas ARP leídas del router: %d", len(arp_entries))

    now = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S.%f")
    discovered_count = 0
    for e in arp_entries:
        ip_addr = (e.get("ip") or "").strip()
        mac = (e.get("mac") or "").strip()
        if not ip_addr or not mac:
            logger.debug("Entrada ARP descartada: ip o mac vacíos")
            continue
        device_info = {
            "ip_address": ip_addr,
            "mac_address": mac,
            "hostname": (e.get("hostname") or "").strip() or "",
            "vendor": (e.get("vendor") or "").strip() or "",
            "last_seen": now,
            "status": "online",
        }
        if save_discovered_device(device_info):
            discovered_count += 1

    cleanup_old_discoveries()
    sync_arp_to_assets(arp_entries, now)

    logger.info("=" * 60)
    logger.info("Inventario pasivo completado. Dispositivos actualizados: %d", discovered_count)
    logger.info("=" * 60)
    return discovered_count


def main():
    """Función principal"""
    try:
        run_discovery()
    except Exception as e:
        logger.error(f"Error fatal en discovery: {str(e)}", exc_info=True)
        return 1
    
    return 0


if __name__ == "__main__":
    import sys
    sys.exit(main())
