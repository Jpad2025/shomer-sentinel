# SCRIPT DE DISCOVERY AUTOMATIZADO DE RED
# Ubicación: /opt/network_monitor/app/backend/scripts/discovery.py

import subprocess
import json
import sqlite3
import socket
import time
from contextlib import contextmanager
from datetime import datetime, timedelta
from typing import List, Dict, Tuple
import ipaddress
import logging

# Configuración
DB_PATH = "/opt/network_monitor/database/network_monitor.db"
NETWORK_RANGE = "192.168.1.0/24"  # Ajustar según tu red
TIMEOUT = 2  # Segundos de timeout para ping/escaneo
CONNECT_TIMEOUT = 30  # SQLite: espera hasta 30 s si la BD está bloqueada

# Configuración de logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('/opt/network_monitor/logs/discovery.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)


@contextmanager
def get_conn():
    """Conexión SQLite con timeout y WAL. Usar con 'with'."""
    conn = sqlite3.connect(DB_PATH, timeout=CONNECT_TIMEOUT)
    conn.execute("PRAGMA journal_mode=WAL;")
    conn.row_factory = sqlite3.Row
    try:
        yield conn
    finally:
        conn.close()


def ping_device(ip: str) -> bool:
    """Verificar si un dispositivo responde a ping"""
    try:
        result = subprocess.run(
            ['ping', '-c', '1', '-W', str(TIMEOUT), ip],
            capture_output=True, text=True
        )
        return result.returncode == 0
    except Exception as e:
        logger.error(f"Error haciendo ping a {ip}: {str(e)}")
        return False


def scan_ports(ip: str, ports: List[int]) -> List[int]:
    """Escanear puertos específicos en un dispositivo"""
    open_ports = []
    for port in ports:
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(TIMEOUT)
            result = sock.connect_ex((ip, port))
            if result == 0:
                open_ports.append(port)
            sock.close()
        except Exception:
            pass
    return open_ports


def get_mac_address(ip: str) -> str:
    """Obtener dirección MAC usando ARP"""
    try:
        # Ping primero para llenar la tabla ARP (usar mismo TIMEOUT global)
        subprocess.run(['ping', '-c', '1', '-W', str(TIMEOUT), ip],
                       capture_output=True, text=True)
        time.sleep(0.5)
        
        # Leer tabla ARP
        result = subprocess.run(['arp', '-n', ip], 
                               capture_output=True, text=True)
        
        # Parsear salida de ARP
        for line in result.stdout.split('\n'):
            if ip in line:
                parts = line.split()
                if len(parts) >= 3:
                    mac = parts[2]
                    if ':' in mac or '-' in mac:
                        return mac.upper().replace('-', ':')
    except Exception as e:
        logger.error(f"Error obteniendo MAC para {ip}: {str(e)}")
    return None

def infer_device_type(ip: str, open_ports: List[int]) -> str:
    """Inferir tipo de dispositivo basado en puertos abiertos"""
    if 22 in open_ports or 80 in open_ports:
        if 161 in open_ports:
            return "router"
        return "router"  # SSH/HTTP típicamente routers/APs
    elif 161 in open_ports:
        return "switch"
    elif 443 in open_ports:
        return "access_point"
    return "unknown"


def discover_device(ip: str) -> Dict:
    """Descubrir información de un dispositivo"""
    logger.info(f"Escaneando dispositivo: {ip}")
    
    # Verificar si responde
    if not ping_device(ip):
        logger.debug(f"{ip} - No responde a ping")
        return None
    
    # Obtener MAC address
    mac = get_mac_address(ip)
    
    # Escanear puertos comunes
    common_ports = [22, 80, 443, 161, 8080, 8443]
    open_ports = scan_ports(ip, common_ports)
    
    if not open_ports:
        logger.debug(f"{ip} - Sin puertos abiertos")
        return None
    
    # Inferir tipo de dispositivo
    device_type = infer_device_type(ip, open_ports)
    
    # Obtener hostname (si es posible)
    hostname = None
    try:
        hostname = socket.gethostbyaddr(ip)[0]
    except Exception:
        pass
    
    device_info = {
        "ip_address": ip,
        "mac_address": mac,
        "hostname": hostname,
        "open_ports": json.dumps(open_ports),
        "inferred_type": device_type,
        "status": "online",
        "source": "pyconnect",
        "first_seen": datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S.%f"),
        "last_seen": datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S.%f")
    }
    
    logger.info(f"Dispositivo descubierto: {ip} - Type: {device_type} - Ports: {open_ports}")
    return device_info


def save_discovered_device(device_info: Dict):
    """Guardar dispositivo descubierto en la base de datos"""
    try:
        with get_conn() as conn:
            cur = conn.cursor()
            cur.execute(
                "SELECT id, last_seen FROM discovered_devices WHERE ip_address = ?",
                (device_info["ip_address"],)
            )
            existing = cur.fetchone()
            if existing:
                cur.execute("""
                    UPDATE discovered_devices
                    SET mac_address = ?, hostname = ?, open_ports = ?, inferred_type = ?, status = ?, last_seen = ?
                    WHERE ip_address = ?
                """, (
                    device_info["mac_address"], device_info["hostname"], device_info["open_ports"],
                    device_info["inferred_type"], device_info["status"], device_info["last_seen"],
                    device_info["ip_address"]
                ))
                logger.info(f"Actualizado dispositivo descubierto: {device_info['ip_address']}")
            else:
                cur.execute("""
                    INSERT INTO discovered_devices (
                        ip_address, mac_address, hostname, open_ports,
                        inferred_type, status, source, first_seen, last_seen
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    device_info["ip_address"], device_info["mac_address"], device_info["hostname"],
                    device_info["open_ports"], device_info["inferred_type"], device_info["status"],
                    device_info["source"], device_info["first_seen"], device_info["last_seen"]
                ))
                logger.info(f"Nuevo dispositivo descubierto: {device_info['ip_address']}")
            conn.commit()
    except Exception as e:
        logger.error(f"Error guardando dispositivo {device_info['ip_address']}: {str(e)}")


def cleanup_old_discoveries():
    """Marcar dispositivos offline que no se han visto en X tiempo"""
    try:
        with get_conn() as conn:
            cur = conn.cursor()
            cutoff = (datetime.utcnow() - timedelta(minutes=30)).strftime("%Y-%m-%d %H:%M:%S.%f")
            cur.execute(
                "UPDATE discovered_devices SET status = 'offline' WHERE last_seen < ? AND status = 'online'",
                (cutoff,)
            )
            if cur.rowcount > 0:
                logger.info(f"Marcados {cur.rowcount} dispositivos como offline")
            conn.commit()
    except Exception as e:
        logger.error(f"Error limpiando discoveries viejos: {str(e)}")


def run_discovery():
    """Ejecutar discovery completo de la red"""
    logger.info("=" * 60)
    logger.info("Iniciando discovery de red")
    logger.info("=" * 60)
    
    start_time = time.time()
    
    # Obtener rango de IPs a escanear
    network = ipaddress.ip_network(NETWORK_RANGE)
    ips_to_scan = [str(ip) for ip in network.hosts()]
    
    logger.info(f"Escaneando {len(ips_to_scan)} IPs en {NETWORK_RANGE}")
    
    discovered_count = 0
    
    # Escanear cada IP
    for ip in ips_to_scan:
        try:
            device_info = discover_device(ip)
            if device_info:
                save_discovered_device(device_info)
                discovered_count += 1
        except Exception as e:
            logger.error(f"Error escaneando {ip}: {str(e)}")
    
    # Limpiar discoveries viejos
    cleanup_old_discoveries()
    
    elapsed = time.time() - start_time
    
    logger.info("=" * 60)
    logger.info(f"Discovery completado en {elapsed:.2f} segundos")
    logger.info(f"Dispositivos descubiertos: {discovered_count}")
    logger.info("=" * 60)
    
    return discovered_count


def main():
    """Función principal"""
    try:
        run_discovery()
    except Exception as e:
        logger.error(f"Error fatal en discovery: {str(e)}", exc_info=True)
        return 1
    
    return 0


if __name__ == "__main__":
    import sys
    from datetime import timedelta
    
    sys.exit(main())
