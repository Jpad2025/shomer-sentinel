from .database import engine, Base, SessionLocal
from .models import Device, DeviceType

def init_db():
    print("Inicializando base de datos...")
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    
    # Verificar si ya existen dispositivos
    if db.query(Device).count() == 0:
        print("Creando dispositivos de ejemplo...")
        devices = [
            Device(name="TP-Link Archer C54", ip_address="192.168.1.200", brand="tplink", device_type=DeviceType.router, ssh_user="admin", ssh_password="Usbing08*"),
            Device(name="Netgear AC1000", ip_address="192.168.1.201", brand="netgear", device_type=DeviceType.router, ssh_user="admin", ssh_password="Usbing08*")
        ]
        db.add_all(devices)
        db.commit()
        print(f"{len(devices)} dispositivos creados.")
    else:
        print("La base de datos ya contiene dispositivos.")
    
    db.close()

if __name__ == "__main__":
    init_db()
