from fastapi import FastAPI, Response, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from datetime import datetime
import uvicorn

from db import get_connection
from routes import devices, discovery, reboot

#from routes import devices, discovery  # requiere routes/__init__.py, reboot

app = FastAPI(
    title="Network Monitor API - USB Ingeniería SAS",
    version="2.0.0",
    docs_url="/api/docs",
    redoc_url="/api/redoc",
    openapi_url="/api/openapi.json"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # ajusta en producción
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Routers
app.include_router(devices.router)
app.include_router(discovery.router)
app.include_router(reboot.router)

@app.get("/api")
async def api_root():
    return {
        "message": "Network Monitor - Sistema Activo",
        "company": "USB Ingeniería SAS / USB Engineers LLC",
        "version": "2.0.0",
        "timestamp": datetime.utcnow().isoformat(),
        "endpoints": {
            "devices": "/api/devices",
            "discovery": "/api/discovery",
            "docs": "/api/docs",
            "redoc": "/api/redoc"
        }
    }

@app.get("/api/", include_in_schema=False)
async def api_root_slash():
    return await api_root()

@app.head("/api", include_in_schema=False)
async def api_head(): return Response(status_code=200)

@app.head("/api/", include_in_schema=False)
async def api_head_slash(): return Response(status_code=200)

@app.get("/api/health")
async def health():
    return {"status": "healthy", "timestamp": datetime.utcnow().isoformat()}

@app.head("/api/health", include_in_schema=False)
async def health_head(): return Response(status_code=200)


@app.get("/api/last_cycle")
async def last_cycle():
    try:
        with get_connection() as conn:
            cur = conn.cursor()
            cur.execute("SELECT MAX(last_check) AS last FROM device_status")
            row = cur.fetchone()
            return {"success": True, "last_cycle": row["last"]}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
if __name__ == "__main__":
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=False)
