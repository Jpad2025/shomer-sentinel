"""
Conexión centralizada a SQLite con timeout, modo WAL y context manager.
Evita 'database is locked' cuando el monitor y la API escriben a la vez.
"""
import sqlite3
from contextlib import contextmanager
from typing import Generator

DB_PATH = "/opt/network_monitor/database/network_monitor.db"
CONNECT_TIMEOUT = 30


def connect(timeout: float = CONNECT_TIMEOUT, row_factory=None) -> sqlite3.Connection:
    """Abre una conexión con timeout y modo WAL. Cierra con with o .close()."""
    conn = sqlite3.connect(DB_PATH, timeout=timeout)
    conn.execute("PRAGMA journal_mode=WAL;")
    if row_factory is not None:
        conn.row_factory = row_factory
    else:
        conn.row_factory = sqlite3.Row
    return conn


@contextmanager
def get_connection(timeout: float = CONNECT_TIMEOUT) -> Generator[sqlite3.Connection, None, None]:
    """Context manager: abre conexión con timeout y WAL y la cierra al salir."""
    conn = connect(timeout=timeout)
    try:
        yield conn
    finally:
        conn.close()
