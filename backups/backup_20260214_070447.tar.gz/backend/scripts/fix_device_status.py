#!/usr/bin/env python3
"""
Migración: añade uptime_percentage (y response_time si falta) a device_status si no existen.
"""
import sqlite3
import sys

DB_PATH = "/opt/network_monitor/database/network_monitor.db"


def column_exists(conn, table: str, column: str) -> bool:
    cur = conn.cursor()
    cur.execute("PRAGMA table_info(%s)" % table)
    return any(row[1] == column for row in cur.fetchall())


def main():
    try:
        conn = sqlite3.connect(DB_PATH, timeout=30)
        conn.execute("PRAGMA journal_mode=WAL;")
        added = []
        for col, typ in [("response_time", "REAL"), ("uptime_percentage", "REAL")]:
            if not column_exists(conn, "device_status", col):
                conn.execute("ALTER TABLE device_status ADD COLUMN %s %s" % (col, typ))
                conn.commit()
                added.append(col)
        conn.close()
        if added:
            print("Columnas añadidas a device_status:", ", ".join(added))
        else:
            print("device_status ya tenía las columnas necesarias.")
        return 0
    except Exception as e:
        print("Error:", e, file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
