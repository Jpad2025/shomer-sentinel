#!/usr/bin/env python3
"""
Actualiza la tabla devices con nombres profesionales para USB SHOMER.
"""
import sqlite3
import sys
from datetime import datetime

DB_PATH = "/opt/network_monitor/database/network_monitor.db"

NAMES = {
    "192.168.1.205": "USB SHOMER (Server)",
    "192.168.1.88": "Admin Console",
    "192.168.1.210": "Gateway GL-MT6000",
}


def main():
    conn = sqlite3.connect(DB_PATH, timeout=30)
    conn.execute("PRAGMA journal_mode=WAL;")
    cur = conn.cursor()
    now = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
    for ip, name in NAMES.items():
        cur.execute("UPDATE devices SET name = ?, updated_at = ? WHERE ip_address = ?", (name, now, ip))
        if cur.rowcount:
            print(f"Actualizado: {ip} -> {name}")
        else:
            cur.execute(
                "INSERT INTO devices (name, device_type, ip_address, is_active, created_at, updated_at) VALUES (?, 'workstation', ?, 1, ?, ?)",
                (name, ip, now, now),
            )
            print(f"Creado: {ip} -> {name}")
    conn.commit()
    conn.close()
    print("Nombres profesionales aplicados.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
