#!/usr/bin/env python3
"""
Migración urgente: añade la columna status a la tabla devices si no existe.
ALTER TABLE devices ADD COLUMN status TEXT DEFAULT 'unknown';
"""
import sqlite3
import sys

DB_PATH = "/opt/network_monitor/database/network_monitor.db"


def main():
    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA journal_mode=WAL;")
    cur = conn.cursor()
    cur.execute("PRAGMA table_info(devices)")
    cols = [row[1] for row in cur.fetchall()]
    if "status" in cols:
        print("La columna status ya existe en devices.")
        conn.close()
        return 0
    try:
        conn.execute("ALTER TABLE devices ADD COLUMN status TEXT DEFAULT 'unknown'")
        conn.commit()
        print("Columna status añadida a devices (DEFAULT 'unknown').")
    except sqlite3.OperationalError as e:
        print("Error:", e, file=sys.stderr)
        conn.close()
        return 1
    conn.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
