#!/usr/bin/env python3
"""Añade columna is_guest (INTEGER DEFAULT 0) a devices si no existe."""
import sqlite3
import sys

DB_PATH = "/opt/network_monitor/database/network_monitor.db"


def main():
    conn = sqlite3.connect(DB_PATH, timeout=30)
    conn.execute("PRAGMA journal_mode=WAL;")
    cur = conn.cursor()
    cur.execute("PRAGMA table_info(devices)")
    cols = [row[1] for row in cur.fetchall()]
    if "is_guest" not in cols:
        conn.execute("ALTER TABLE devices ADD COLUMN is_guest INTEGER DEFAULT 0")
        conn.commit()
        print("Columna is_guest añadida a devices.")
    else:
        print("Columna is_guest ya existe.")
    conn.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
