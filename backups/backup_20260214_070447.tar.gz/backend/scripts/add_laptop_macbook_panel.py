#!/usr/bin/env python3
"""
Añade o actualiza en devices las IPs 192.168.1.20 (Laptop Prueba) y 192.168.1.27 (MacBook Prueba)
para que el panel y el monitor los incluyan.
"""
import sqlite3
import sys
from datetime import datetime

DB_PATH = "/opt/network_monitor/database/network_monitor.db"

DEVICES = [
    ("192.168.1.20", "Laptop Prueba"),
    ("192.168.1.27", "MacBook Prueba"),
]


def main():
    conn = sqlite3.connect(DB_PATH, timeout=30)
    conn.execute("PRAGMA journal_mode=WAL;")
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    now = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")

    for ip, name in DEVICES:
        cur.execute("SELECT id FROM devices WHERE ip_address = ?", (ip,))
        r = cur.fetchone()
        if r:
            cur.execute(
                "UPDATE devices SET name = ?, is_active = 1, updated_at = ? WHERE id = ?",
                (name, now, r["id"]),
            )
            print(f"Actualizado: {ip} -> {name} (id={r['id']})")
        else:
            cur.execute(
                """INSERT INTO devices (name, device_type, ip_address, is_active, created_at, updated_at)
                   VALUES (?, 'workstation', ?, 1, ?, ?)""",
                (name, ip, now, now),
            )
            did = cur.lastrowid
            cur.execute(
                "INSERT INTO device_status (device_id, status, last_check) VALUES (?, 'unknown', ?)",
                (did, now),
            )
            print(f"Creado: {ip} -> {name} (id={did})")

    conn.commit()
    conn.close()
    print("Listo. Laptop Prueba y MacBook Prueba en panel y en bucle de ping del monitor.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
