#!/usr/bin/env python3
"""
Configura la BD con los dispositivos del monitoreo failsafe:
- Router GL 192.168.1.210 (root / Usbing08@2026) — reinicio vía SSH
- Laptop 192.168.1.20 — objetivo de ping
- MacBook 192.168.1.27 — objetivo de ping
Cada uno queda registrado en devices y device_status para reportes de estabilidad.
"""
import sqlite3
import sys
from datetime import datetime

DB_PATH = "/opt/network_monitor/database/network_monitor.db"

ROUTER_IP = "192.168.1.210"
ROUTER_USER = "root"
ROUTER_PASSWORD = "Usbing08@2026"
LAPTOP_IP = "192.168.1.20"
MACBOOK_IP = "192.168.1.27"


def main():
    conn = sqlite3.connect(DB_PATH, timeout=30)
    conn.execute("PRAGMA journal_mode=WAL;")
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()

    now = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")

    # Router GL: debe quedar siempre como id=5 (API y monitor usan GL_ROUTER_DEVICE_ID=5)
    cur.execute("SELECT id FROM devices WHERE id = 5")
    row5 = cur.fetchone()
    cur.execute("SELECT id FROM devices WHERE ip_address = ?", (ROUTER_IP,))
    row_ip = cur.fetchone()
    if row5:
        if row_ip and row_ip["id"] != 5:
            cur.execute("UPDATE devices SET ip_address = ? WHERE id = ?", (ROUTER_IP + ".bak", row_ip["id"]))
        cur.execute(
            """UPDATE devices SET name = ?, device_type = 'router', ip_address = ?, ssh_user = ?, ssh_password = ?, is_active = 1, updated_at = ?
               WHERE id = 5""",
            ("GL-MT6000", ROUTER_IP, ROUTER_USER, ROUTER_PASSWORD, now),
        )
        print(f"Router {ROUTER_IP} configurado (id=5)")
    else:
        if row_ip:
            cur.execute("UPDATE devices SET ip_address = ? WHERE id = ?", (ROUTER_IP + ".bak", row_ip["id"]))
        cur.execute(
            """INSERT INTO devices (id, name, device_type, ip_address, is_active, ssh_user, ssh_password, created_at, updated_at)
               VALUES (5, ?, 'router', ?, 1, ?, ?, ?, ?)""",
            ("GL-MT6000", ROUTER_IP, ROUTER_USER, ROUTER_PASSWORD, now, now),
        )
        cur.execute("INSERT INTO device_status (device_id, status, last_check) VALUES (5, 'unknown', ?)", (now,))
        print(f"Router {ROUTER_IP} creado (id=5)")

    # Laptop
    cur.execute("SELECT id FROM devices WHERE ip_address = ?", (LAPTOP_IP,))
    r = cur.fetchone()
    if r:
        cur.execute(
            "UPDATE devices SET name = ?, is_active = 1, updated_at = ? WHERE id = ?",
            ("Laptop", now, r["id"]),
        )
        print(f"Laptop {LAPTOP_IP} actualizado (id={r['id']})")
    else:
        cur.execute(
            """INSERT INTO devices (name, device_type, ip_address, is_active, created_at, updated_at)
               VALUES (?, 'workstation', ?, 1, ?, ?)""",
            ("Laptop", LAPTOP_IP, now, now),
        )
        lid = cur.lastrowid
        cur.execute(
            "INSERT INTO device_status (device_id, status, last_check) VALUES (?, 'unknown', ?)",
            (lid, now),
        )
        print(f"Laptop {LAPTOP_IP} creado (id={lid})")

    # MacBook
    cur.execute("SELECT id FROM devices WHERE ip_address = ?", (MACBOOK_IP,))
    r = cur.fetchone()
    if r:
        cur.execute(
            "UPDATE devices SET name = ?, is_active = 1, updated_at = ? WHERE id = ?",
            ("MacBook", now, r["id"]),
        )
        print(f"MacBook {MACBOOK_IP} actualizado (id={r['id']})")
    else:
        cur.execute(
            """INSERT INTO devices (name, device_type, ip_address, is_active, created_at, updated_at)
               VALUES (?, 'workstation', ?, 1, ?, ?)""",
            ("MacBook", MACBOOK_IP, now, now),
        )
        mid = cur.lastrowid
        cur.execute(
            "INSERT INTO device_status (device_id, status, last_check) VALUES (?, 'unknown', ?)",
            (mid, now),
        )
        print(f"MacBook {MACBOOK_IP} creado (id={mid})")

    conn.commit()
    conn.close()
    print("Seed completado. Router, Laptop y MacBook listos para monitoreo y reportes.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
