# Este archivo hace que routes sea un paquete Python
from . import devices, discovery, reboot, backup, inventory
__all__ = ["devices", "discovery", "reboot", "backup", "inventory"]