PRAGMA journal_mode=WAL;
PRAGMA synchronous=NORMAL;

CREATE TABLE IF NOT EXISTS devices (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT,
  device_type TEXT,
  ip_address TEXT UNIQUE,
  mac_address TEXT,
  brand TEXT,
  model TEXT,
  location TEXT,
  is_active INTEGER DEFAULT 1
);

CREATE TABLE IF NOT EXISTS device_status (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  device_id INTEGER NOT NULL,
  status TEXT,
  last_check TEXT,
  response_time REAL,
  uptime_percentage REAL,
  FOREIGN KEY(device_id) REFERENCES devices(id)
);

CREATE TABLE IF NOT EXISTS events_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  device_id INTEGER NOT NULL,
  event_type TEXT,
  description TEXT,
  timestamp TEXT,
  FOREIGN KEY(device_id) REFERENCES devices(id)
);

CREATE TABLE IF NOT EXISTS discovered_devices (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ip_address    TEXT NOT NULL UNIQUE,
  mac_address   TEXT,
  vendor        TEXT,
  hostname      TEXT,
  open_ports    TEXT,
  inferred_type TEXT,
  status        TEXT,
  source        TEXT,
  first_seen    TEXT,
  last_seen     TEXT
);

CREATE INDEX IF NOT EXISTS idx_device_status_device_time
  ON device_status(device_id, last_check);

CREATE INDEX IF NOT EXISTS idx_devices_active_name
  ON devices(is_active, name);

CREATE INDEX IF NOT EXISTS idx_disc_last_seen
  ON discovered_devices(last_seen);
